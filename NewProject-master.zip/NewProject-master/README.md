# NewProject
<body>
  <h1>This is my new project for when I get bored and wanna learn more about coding.</h1>
  <h2>So far I've learned how to use headers effectively and that's about it.</h2>
  <p><span>Update:</span>I've learned paragraphs now and also something called span that from my understanding separates things that would all be on one line. Similar to if I had said Update:.</p>
